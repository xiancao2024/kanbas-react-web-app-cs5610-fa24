export default function   People() {
    return (
      <div id="wd-piazza">
        <h2>People</h2>
        <p>Piazza is not available for this course.</p>
      
      </div>
    );
  }