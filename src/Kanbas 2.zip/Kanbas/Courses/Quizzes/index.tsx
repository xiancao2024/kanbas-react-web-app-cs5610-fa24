export default function     Quizzes() {
  return (
    <div id="wd-quizzes">
      <h2>Quizzes</h2>
      <p>Quizzes are not available for this course.</p>
    
    </div>
  );
} 