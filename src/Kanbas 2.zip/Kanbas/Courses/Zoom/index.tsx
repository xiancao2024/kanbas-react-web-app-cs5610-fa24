export default function   Zoom() {
  return (
    <div id="wd-zoom">
      <h2>Zoom</h2>
      <p>Zoom is not available for this course.</p>
    
    </div>
  );
}