export default function   Piazza() {
  return (
    <div id="wd-piazza">
      <h2>Piazza</h2>
      <p>Piazza is not available for this course.</p>
    
    </div>
  );
}