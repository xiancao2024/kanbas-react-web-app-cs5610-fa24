export default function     Grades() {
  return (
    <div id="wd-grades">
      <h2>Grades</h2>
      <p>Grades are not available for this course.</p>
    
    </div>
  );
}